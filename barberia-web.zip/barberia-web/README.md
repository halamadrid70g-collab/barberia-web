# BLACKLINE — plantilla de barbería

Página de demostración para personalizar y ofrecer a un negocio.

## Archivos
- `index.html`: estructura y contenido.
- `css/style.css`: diseño, colores y adaptación a móviles.
- `js/script.js`: menú móvil, año automático y enlace de WhatsApp.

## Cómo verla
1. Descarga y descomprime `barberia-web.zip`.
2. Abre `index.html` con Chrome, Edge o Firefox.
3. Para editarla, abre la carpeta con Visual Studio Code.

## Antes de venderla
- Cambia BLACKLINE por el nombre real.
- Actualiza los precios de ejemplo.
- Cambia `whatsappNumber` en `js/script.js` por el número del negocio.
- Revisa textos, horarios, dirección, servicios e imágenes.
- Usa fotos propias o imágenes con licencia adecuada; las fotos remotas de esta demo necesitan internet.
- No prometas reservas automáticas: el botón solo abre WhatsApp.

## Publicación gratis con GitHub Pages
1. Crea una cuenta en GitHub.
2. Crea un repositorio público llamado `barberia-web`.
3. Sube `index.html` y las carpetas `css` y `js` (no subas solo el ZIP).
4. Abre **Settings → Pages**.
5. En **Build and deployment**, selecciona **Deploy from a branch**, rama `main` y carpeta `/(root)`.
6. Guarda y espera a que GitHub Pages muestre la URL pública del sitio.

## Nota
Los precios y la marca son de ejemplo. Antes de usar el sitio con un cliente, confirma que tiene permiso para usar el nombre, el contenido y las imágenes.
